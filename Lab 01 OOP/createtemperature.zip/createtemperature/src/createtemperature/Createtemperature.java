
package createtemperature;

import javax.swing.JOptionPane;  
  
public class Createtemperature {  
 public static void main(String[] args){
        String more = "y";
        while(more.equalsIgnoreCase("Y")){       
        String unit = JOptionPane.showInputDialog("Enter unit F or C: ");      
        String temp1 = JOptionPane.showInputDialog("Enter the Temperature: ");       
        double temp = Double.valueOf(temp1).doubleValue();
         if((unit.equals("F"))||(unit.equals("f"))){
        double c= (temp - 32) / 1.8;
        JOptionPane.showMessageDialog(null,c+" Celsius");
        }
         else if((unit.equals("C"))||(unit.equals("c"))){
        double f=((9.0 / 5.0) * temp) + 32.0;
        JOptionPane.showMessageDialog(null,f+" Fahrenheit");
        } 
         more = JOptionPane.showInputDialog("Continue - Y for yes");
} 
       
}
}